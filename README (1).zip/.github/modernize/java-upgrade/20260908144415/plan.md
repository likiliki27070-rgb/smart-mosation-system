# Upgrade Plan: driver-drowsiness-standalone (20260908144415)

- **Generated**: 2026-09-08 14:44:15
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 21.0.11: `C:\Program Files\Java\jdk-21.0.11\bin` (available base/runtime reference)
- JDK 25: **<TO_BE_INSTALLED>** (required for the target runtime)

**Build Tools**
- Maven: **<TO_BE_INSTALLED>** (required; no standalone Maven installation detected)

> Version control is unavailable because the workspace is not a Git repository. Changes will remain in the working directory.

## Guidelines

- Upgrade the Java runtime to the latest LTS version, Java 25.
- Preserve application behavior and keep changes limited to runtime/build compatibility.

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260908144415
- Run tests before and after the upgrade: true

## Upgrade Goals

- Java 25

## Technology Stack

| Technology/Dependency | Current | Min Compatible Version | Why Incompatible |
| --------------------- | ------- | ---------------------- | ---------------- |
| Java | 17 | 25 | User requested latest LTS runtime |
| Spring Boot | 3.2.5 | 3.5.6 | Spring Boot 3.2.5 repackage plugin cannot process Java 25 class files |
| Maven | Not installed | 3.9+ | Maven is required for compilation and tests on modern JDKs |
| maven-compiler-plugin | Spring Boot parent managed | 3.13+ recommended | Java 25 compilation support should use a current compiler plugin |
| Spring Data JPA | Spring Boot managed | 3.2.5 | Retain; no direct runtime incompatibility identified |

## Derived Upgrades

- Install JDK 25 because it is the requested latest LTS runtime and is not currently available.
- Install Maven 3.9+ because Maven is not installed and current Maven versions are recommended for Java 25.
- Use the compiler `release` setting through `${java.version}` so main and test code target Java 25 consistently.
- Upgrade `maven-compiler-plugin` only if required by Java 25 compilation; retain Spring Boot 3.2.5 unless validation proves a framework compatibility issue.

## Impact Analysis

### Dependency Changes

| File | Dependency | Current | Action | Target | Reason |
|------|------------|---------|--------|--------|--------|
| `pom.xml` | `spring-boot-starter-parent` | 3.2.5 | upgrade | 3.5.6 | Java 25-compatible Spring Boot build tooling |
| `pom.xml` | `java.version` | 17 | upgrade | 25 | Set the project compilation/runtime target to Java 25 |
| `pom.xml` | `maven-compiler-plugin` | Parent-managed | upgrade if required | Current Java 25-compatible release | Ensure compiler plugin supports Java 25 without changing unrelated dependencies |

### Source Code Changes

| File | Location | Current | Required Change | Reason |
|------|----------|---------|----------------|--------|
| None identified | N/A | Existing Java 17-compatible APIs | No source changes expected | The code uses standard Java/Spring APIs and the target is a forward-compatible runtime upgrade |

### Configuration Changes

| File | Property/Setting | Current | Required Change | Reason |
|------|------------------|---------|----------------|--------|
| `README.md` | Prerequisites | JDK 17 or above | Update to JDK 25 or above | Keep setup documentation aligned with the supported runtime |

### CI/CD Changes

| File | Location | Current | Required Change |
|------|----------|---------|----------------|
| None identified | N/A | No CI/CD configuration present | No change |

### Risks & Warnings

- **JDK 25 availability**: JDK 25 is not installed. **Mitigation**: Install a trusted JDK 25 distribution before compiling.
- **Spring Boot 3.2.5 on Java 25**: This older Spring Boot line may not be officially validated against Java 25. **Mitigation**: Keep the framework unchanged initially, run full compilation and tests, and only apply a minimal compatibility upgrade if validation fails.
- **No baseline JDK 17**: The machine has JDK 21 rather than JDK 17, so an exact pre-upgrade Java 17 baseline cannot be run. **Mitigation**: Run the available JDK 21 build as an informational baseline where possible, then require successful Java 25 compile and tests.
- **No version control**: The folder is not a Git repository. **Mitigation**: Track all changes in `progress.md` and `summary.md`; no commits or branch operations are possible.

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Install the required JDK 25 and Maven tooling before any build verification.
  - **Changes to Make**: Install JDK 25 and Maven 3.9+.
  - **Verification**: List installed JDKs and Maven; expected JDK 25 and Maven available.

- Step 2: Setup Baseline
  - **Rationale**: Establish pre-upgrade build/test evidence where the available environment permits.
  - **Changes to Make**: No project changes.
  - **Verification**: Run Maven compile/test with the available base JDK; document exact availability limitation if JDK 17 is absent.

- Step 3: Upgrade Java Runtime Target
  - **Rationale**: Apply the requested Java 25 target and any compiler plugin adjustment required for compilation.
  - **Changes to Make**: Apply all Dependency Changes and Configuration Changes above.
  - **Verification**: `mvn clean test-compile -q` using JDK 25; expected successful main and test compilation.

- Step 4: Final Validation
  - **Rationale**: Confirm the upgraded project builds and all tests pass on Java 25.
  - **Changes to Make**: Resolve any Java 25-specific compilation or test failures discovered in Step 3.
  - **Verification**: `mvn clean test -q` using JDK 25; expected 100% test pass rate.

- Step 5: CVE Validation & Fix
  - **Rationale**: Check direct dependencies after the runtime upgrade and remediate any reported vulnerabilities.
  - **Changes to Make**: Upgrade only vulnerable dependency versions required by the scan.
  - **Verification**: Rebuild and re-scan; expected no remediable CVEs remain.

- Step 6: Final Validation and Summary
  - **Rationale**: Collect final verification and document the completed upgrade.
  - **Changes to Make**: Generate progress and summary artifacts; update remaining runtime documentation if needed.
  - **Verification**: Run final clean verification and confirm all plan steps are complete.
