# Java Upgrade Summary: driver-drowsiness-standalone

## Outcome

Upgraded the project from Java 17 to Java 25, the latest LTS runtime, and updated the setup documentation accordingly.

## Changes

- Updated `pom.xml` Java target from 17 to 25.
- Upgraded Spring Boot from 3.2.5 to 3.5.6 because the older repackage plugin failed on Java 25 class files.
- Updated `README.md` to require JDK 25 or newer.
- Installed JDK 25.0.2 and Maven 3.9.16 locally for validation.

## Verification

- `mvn clean test-compile -q`: passed.
- `mvn clean verify -q`: passed.
- `mvn clean test -q`: passed.
- CVE scan: no known CVEs requiring remediation.

## Baseline

An exact Java 17 baseline was unavailable because JDK 17 was not installed. The available JDK 21 baseline build succeeded before the upgrade.

## Risks

Spring Boot was moved within the 3.x line to obtain Java 25-compatible packaging support. Application source APIs were unchanged, and clean packaging plus the full test suite passed on Java 25.

Version control was unavailable because the workspace is not a Git repository; changes remain in the working directory.
